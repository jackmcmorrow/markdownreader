//View MarkDown Object
vmd = {};

vmd.element = document.getElementById('viewer');
vmd.maxFileSize = 5; //mb

vmd.update = function(markdownTxt)
{
	vmd.element.innerHTML = markdown.toHTML(markdownTxt);
}

vmd.load = function (fileEntry)
{
	fileEntry.file(function(file) 
	{
		var reader = new FileReader();
		
		reader.readAsText(file); //Fires loadstart();

		reader.onloadend = function() {
			vmd.update(reader.result);
		};

	});
}

var $ = function(selector) {
	var selectorResults = document.querySelectorAll(selector)
	return selectorResults.length > 1 ? selectorResults : selectorResults[0];
}

//Drag and Drop file

var dnd = new DnDFileController('html', function(data) {
  var fileEntry = data.items[0].webkitGetAsEntry();
  //console.info(fileEntry);
  vmd.load(fileEntry);
});

//Load via button
var btnLoadFile = $('#btnLoadFile');
btnLoadFile.onclick = function()
{
	chrome.fileSystem.chooseEntry(
		{
			type: "openFile",
			//accepts: ["md", "txt"],
			acceptsAllTypes: true,
			acceptsMultiple: false
		}, 
		
		function(fileEntry)
		{
			vmd.load(fileEntry[0])
		}
	);
};

//UI Config
var modalConfig = $('#modalConfig'),
	btnOpenConfigModal = $('#openConfigModal'),
	btnCloseConfigModal = $('#closeConfigModal'),
	btnApplyConfigModal = $('#applyConfigs'),
	configInputs = $("#config input, #config select");

configs = {
	theme: 0,
	fontSize: 13,
	lineHeight: 1.8
}

document.forms.config.theme[configs.theme].selected = "selected";
document.forms.config.fontSize.value = configs.fontSize;
document.forms.config.lineHeight.value = configs.lineHeight;

configs.update = function(isPreview)
{
	var style = "";

	style += "font-size: " + configs.fontSize + "px;";
	style += "line-height: " + configs.lineHeight + ";";
	style += "background-color: ";
	var theme = parseInt(configs.theme, 10);
	switch(theme){
		case 0:
			style += "#ffffff; color: #000000;"
		break;

		case 1:
			style += "#cccccc; color: #666666;"
		break;

		case 2:
			style += "#000000; color: #ffffff;"
		break;
	}

	style += "margin-top: 0;"
	
	if (isPreview === true)
	{
		styleElement = $('#vmdPreviewTheme')
		styleElement.innerHTML = "#preview, #preview * {" + style + "}";
		//return $("#preview").style = style;

	} else {
		styleElement = $('#vmdTheme')
		styleElement.innerHTML = "body, #viewer * {" + style + "}";
		//return $("body").style = style;
	}

}

configs.update();
configs.update(true);

btnOpenConfigModal.onclick = function()
{
	modalConfig.style.display = 'block';
}

btnCloseConfigModal.onclick = function()
{
	modalConfig.style.display = 'none';
}

btnApplyConfigModal.onclick = function()
{
	configs.update();
	modalConfig.style.display = 'none';
}

for (var input = configInputs.length - 1; input >= 0; input--) {
	configInputs[input].onchange = function()
	{
		configs[this.name] = this.value;
		console.log(configs);
		configs.update(true);
	}
};